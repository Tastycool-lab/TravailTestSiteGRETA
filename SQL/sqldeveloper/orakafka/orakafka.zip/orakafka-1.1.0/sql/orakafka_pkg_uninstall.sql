Rem
Rem $Header: hadoop/projects/dbmskafka/src/main/plsql/orakafka_pkg_uninstall.sql /main/2 2019/06/05 08:28:24 smavris Exp $
Rem
Rem orakafka_pkg_uninstall.sql
Rem
Rem Copyright (c) 2018, 2019, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      orakafka_pkg_uninstall.sql - Script to uninstall ORA_KAFKA package.
Rem
Rem    DESCRIPTION
Rem      Uninstall ORA_KAFKA and ORA_KAFKA_UTL packages
Rem
Rem    NOTES
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: hadoop/projects/orakafka/src/main/plsql/orakafka_pkg_uninstall.sql
Rem    SQL_SHIPPED_FILE: <ORAKAFKA_HOME>/sql/orakafka_pkg_uninstall.sql
Rem    SQL_PHASE:
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    smavris     05/30/19 - Cleanup comments
Rem    myalavar    05/06/19 - dbms_kafka -> ora_kafka
Rem    royan       06/29/18 - Created
Rem

DROP PACKAGE ORA_KAFKA_UTL;

DROP PACKAGE ORA_KAFKA;
 
