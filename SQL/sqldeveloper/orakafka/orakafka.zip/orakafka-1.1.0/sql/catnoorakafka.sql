Rem Copyright (c) 2018, 2019, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catnoorakafka.sql
Rem
Rem    DESCRIPTION
Rem      This script deinstalls the Oracle ORA_KAFKA
Rem      packages and related metadata tables.
Rem
Rem    NOTES
Rem      See Documentation.
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: hadoop/projects/dbmskafka/src/main/plsql/catnoorakafka.sql
Rem    SQL_SHIPPED_FILE: <ORAKAFKA_HOME>/sql/catnoorakafka.sql
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    END SQL_FILE_METADATA
Rem    
Rem    MODIFIED   (MM/DD/YY)
Rem    smavris     05/30/19 - Cleanup comments
Rem    myalavar    05/06/19 - dbms_kafka -> ora_kafka
Rem    royan       06/29/18 - Drop DBMS_KAFKA package in 
Rem                           dbmskafka_pkg_uninstall.sql
Rem    rhanckel    05/27/18 - Created
Rem


prompt .. Removing ORA_KAFKA artifacts

Rem drop metadata tables for ORA_KAFKA packages

DROP TABLE ORA_KAFKA_PARTITION;

DROP TABLE ORA_KAFKA_LOAD_METRICS;

DROP TABLE ORA_KAFKA_APPLICATION;

DROP TABLE ORA_KAFKA_CLUSTER;

@@orakafka_pkg_uninstall.sql
