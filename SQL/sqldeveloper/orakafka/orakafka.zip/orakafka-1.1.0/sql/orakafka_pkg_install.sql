Rem
Rem $Header: hadoop/projects/dbmskafka/src/main/plsql/orakafka_pkg_install.sql /main/1 2019/05/08 12:16:46 myalavar Exp $
Rem
Rem orakafka_pkg_install.sql
Rem
Rem Copyright (c) 2018, 2019, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      orakafka_pkg_install.sql - Script to install ORA_KAFKA package
Rem
Rem    DESCRIPTION
Rem      Installs ORA_KAFKA package and associated private packages and
Rem      and associated metadata tables.
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: hadoop/projects/orakafka/src/main/plsql/orakafka_pkg_install.sql
Rem    SQL_SHIPPED_FILE:
Rem    SQL_PHASE:
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    myalavar    05/06/19 - dbms_kafka -> ora_kafka
Rem    rhanckel    11/01/18 - wrapped packages
Rem    royan       06/29/18 - Created
Rem

Rem Create specifications for ORA_KAFKA packages

@@orakafkas.sql

@@pvtorakafkaus.plb

Rem Create implementation for ORA_KAFKA packages

@@orakafkab.plb

@@pvtorakafkaub.plb
 
