Rem
Rem Copyright (c) 2018, 2019, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem NAME
Rem
Rem orakafkas.sql - Defines the ORA_KAFKA spec.
Rem
Rem DESCRIPTION
Rem
Rem Specifies the public interface to the ORA_KAFKA package.
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: hadoop/projects/dbmskafka/src/main/plsql/orakafkas.sql
Rem    SQL_SHIPPED_FILE: <ORAKAFKA_HOME>/sql/orakafkas.sql
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    END SQL_FILE_METADATA
Rem
Rem MODIFIED  (MM/DD/YY)
Rem  djoly     10/28/19 - Timestamp support
Rem  rhanckel  09/27/19 - NEDCBD-158 create private or global temp tables
Rem  djoly     09/24/19 - Add partition support
Rem  myalavar  09/16/19 - add view_type constants : nedcbd-151
Rem  djoly     09/09/19 - Update signature of load table
Rem  myalavar  06/21/19 - XbranchMerge
Rem                       myalavar_change_kafka_uris_to_bootstrap_servers from
Rem                       st_hadoop_orakafka1.0.0
Rem  myalavar  06/20/19 - kafka_uri -> bootstrap_servers
Rem  gbalan    06/12/19 - NEDCBD-105: remove fetch_max_bytes from create_views
Rem  smavris   05/30/19 - Add correct headers
Rem  smavris   05/23/19 - Remove zookeeper uri from register_cluster
Rem  djoly     05/21/19 - Add status and error info to bco
Rem  myalavar  05/06/19 - dbms_kafka -> ORA_KAFKA
Rem  myalavar  04/23/19 - Add customizable field/record delim for exttab
Rem  kgayatri  04/22/19 - add cluster_conf_directory to REGISTER_CLUSTER
Rem  djoly     04/22/19 - Switch window to bytes
Rem  djoly     04/18/19 - Remove ADD_PARTITIONS for V1
Rem  rhanckel  04/03/19 - JSON support
Rem  rhanckel  03/08/19 - Interface rev
Rem  rhanckel  02/01/19 - Overloaded renamed procedures
Rem  rhanckel  10/31/18 - lexical order of interfaces
Rem  rhanckel  10/02/18 - add seek offset  
Rem  royan     09/21/18 - set_next_offset -> set_offset and 
Rem                         record_last_offset -> record_offset
Rem  rhanckel  09/24/18 - seek functions
Rem  myalavar  08/28/18 - create_cluster -> register_cluster
Rem  rhanckel  09/11/18 - changing default_batch_size to window_size
Rem  rhanckel  08/31/18 - Add default_batch_size and plsql formatting
Rem  royan     08/30/18 - Make LOAD_TABLE a procedure
Rem  royan     08/21/18 - Add procedure to DROP_KAFKA_VIEWS and DROP_CLUSTER
Rem  royan     08/16/18 - Change partition_id to view_id in SET_NEXT_OFFSET 
Rem                         and RECORD_LAST_OFFSET
Rem  royan     06/29/18 - Add SET_NEXT_OFFSET and RECORD_LAST_OFFSET procedures
Rem  rhanckel  06/26/18 - Got rid of metadata info calls, using system views
Rem  rhanckel  04/18/18 - Created.
Rem

------------------------------------------------------------------------------
-- All procedures and functions in this package are public
------------------------------------------------------------------------------

CREATE OR REPLACE PACKAGE ORA_KAFKA AUTHID CURRENT_USER
IS

  -----------------------------------------------------------------------------
  --            Package Constants
  -----------------------------------------------------------------------------

  TOPIC_FORMAT_CSV           CONSTANT VARCHAR2(3)  := 'CSV';
  TOPIC_FORMAT_JSON_VARCHAR2 CONSTANT VARCHAR2(13) := 'JSON_VARCHAR2';

  VIEW_TYPE_APP              CONSTANT VARCHAR2(16) := 'APPLICATION_VIEW';
  VIEW_TYPE_LOAD_TABLE       CONSTANT VARCHAR2(15) := 'LOAD_TABLE_VIEW';

  WATER_MARK_HIGH            CONSTANT VARCHAR2(3)  := 'WMH';
  WATER_MARK_LOW             CONSTANT VARCHAR2(3)  := 'WML';

  -----------------------------------------------------------------------------
  --            BEGIN PACKAGE INTERFACE
  -----------------------------------------------------------------------------  

  /**
   * Registers the named Kafka cluster. The procedure will register the Kafka 
   * cluster and assign it a unique name.
   *
   * Param cluster_name        (IN) a user supplied name for a Kafka cluster
   *                                (case insensitive)
   * Param bootstrap_servers   (IN) the bootstrap servers of the Kafka cluster
   *                                (case sensitive)
   * Param default_directory   (IN) the Oracle default directory for Kafka 
   *                                external tables (case insensitive)
   * Param location_directory  (IN) the Oracle location directory for Kafka 
   *                                external tables (case insensitive)
   * Param cluster_conf_directory (IN) the cluster configuration directory for
   *                                   the given Kafka cluster (case insensitive)
   * Param cluster_description (IN) (OPTIONAL) a text description of the cluster
   */
  PROCEDURE REGISTER_CLUSTER (
                              cluster_name           IN VARCHAR2,
                              bootstrap_servers      IN VARCHAR2,
                              default_directory      IN VARCHAR2,
                              location_directory     IN VARCHAR2,
                              cluster_conf_directory IN VARCHAR2,
                              cluster_description    IN VARCHAR2 DEFAULT NULL
  );

  /**
   * Return the status and error related messages, if any, after a select
   * call for the view.  If there are multiple partitions defined for the 
   * view and access errors occurred for more than one partition, then only 
   * the last error processed is returned as output.  The assumption is, 
   * that if access to multiple partitions failed, the cause of the failure 
   * will be common to all. 
   *
   * Param view_name              (IN) the name of Kafka view used in a SQL
   *                                   query to read one or more Kafka 
   *                                   partitions on behalf of an application
   * Param status                (OUT) the return status of the fetch of 
   *                                   data from Kafka
   * Param user_friendly_message (OUT) the user friendly message for the
   *                                   failure, if the call failed
   * Param exception_message     (OUT) the message from the exception for the
   *                                   failure, if the call failed
   * Param file_info             (OUT) the message containing the output file
   *                                   name, if the call failed.  This file
   *                                   should have the full stack trace of
   *                                   the error as well as any logging 
   *                                   messages from Kafka
   */
  PROCEDURE CHECK_STATUS(
                          view_name             IN VARCHAR2,
                          status                OUT INTEGER,
                          user_friendly_message OUT VARCHAR2,
                          exception_message     OUT VARCHAR2,
                          file_info             OUT VARCHAR2);

  /**
   * Creates a set of Kafka views mapping to external tables that retrieve 
   * data from partitions in a Kafka topic.  It also creates a view that 
   * inspects live partition information living in a Kafka topic.
   *
   * Each view grabs the contents from one or more partitions in a
   * topic.  This allows an application doing analysis to scale out and
   * divide the workload of analyzing Kafka data across application instances
   * running concurrently on one or more threads, processes, or systems. 
   *
   * This model is restrictive in that only one application instance is
   * allowed to read one of the application views. It is solely responsible
   * for processing one view in an application, and commiting the related
   * Kafka topic offsets.
   *
   * Param cluster_name        (IN) the name of the Kafka cluster 
   *                                (case insensitive)
   * Param group_name          (IN) the Kafka group that will be reading the 
   *                                topic (case sensitive)
   * Param topic_name          (IN) the topic name in the Kafka cluster whose 
   *                                contents will be retrieved (case sensitive)
   * Param topic_record_format (IN) the format of the topic record (e.g. 'CSV')
   *                                See constants above in package 
   *                                specification.
   * Param ref_table           (IN) a table whose shape serves as a reference to
   *                                the shape of the Kafka views created (case 
   *                                insensitive)
   * Param views_created      (OUT) the number of views created
   * Param application_id     (OUT) the application id of the set of views 
   *                                generated that uniquely identifies the view 
   *                                objects dedicated to a cluster, group, and
   *                                topic
   * Param view_count          (IN) (OPTIONAL) identifies the number of views 
   *                                to create legal values are 1 to N where N is
   *                                the number of Kafka partitions in a topic, 
   *                                or 0 which defaults to N. (Default is 0). 
   * Param force_view_count   (IN) (OPTIONAL) set to true if forcing a number 
   *                                of views that could create unbalanced loads 
   *                                where different views support different
   *                                numbers of Kafka topic partitions. (Default
   *                                is FALSE).
   * Param view_properties (IN) (OPTIONAL)
   *                             Includes a list of properties formatted as a 
   *                             JSON string in the JSON syntax described in the 
   *                             JSON developers guide.
   * https://docs.oracle.com/en/database/oracle/oracle-database/19/adjsn/conditions-is-json-and-is-not-json.html#GUID-1B6CFFBE-85FE-41DD-BA14-DD1DE73EAB20
   *                            The supported keys are 
   *                              field_delim: field delimiter as a json value 
   *                              record_delim: record delimiter as a json value 
   *                            Either key or both or none can be specified. 
   *
   *                             Examples:
   *                             {"field_delim":\u0001","record_delim":"\r\n"}
   *                             {"record_delim":"\r\n"}
   *                             {"field_delim":"\u0001"}
   *
   */
  PROCEDURE CREATE_VIEWS (
                          cluster_name         IN  VARCHAR2,
                          group_name           IN  VARCHAR2,
                          topic_name           IN  VARCHAR2,
                          topic_record_format  IN  VARCHAR2,
                          ref_table            IN  VARCHAR2,
                          views_created        OUT INTEGER, 
                          application_id       OUT VARCHAR2,
                          view_count           IN  INTEGER DEFAULT 0,
                          force_view_count     IN  BOOLEAN DEFAULT FALSE,
                          view_properties      IN  VARCHAR2 DEFAULT NULL
  );

  /**
   * Adds additional Kafka partitions to an existing set of Kafka views.
   *
   * This is an adminstrative task that is called after additional Kafka
   * partitions have been added to a topic that is being processed by
   * Kafka views.  It has similar semantics to CREATE_VIEWS calls, except
   * it preserves state information about existing Kafka topic partitions
   * (e.g. committed_offset) and binds new partitions to either existing
   * or new views.
   *
   * Note: When a view is created and the partitions are assigned, the view
   * holds a sequential list of partitions.  For example, if the first view is 
   * to operate against 4 partitions, the partitions would be 0,1,2,3.  If 
   * ADD_PARTITIONS later adds another partition to this view, there is no
   * attempt to keep the list of partitions sequential.  Extending the previous 
   * example, if partition 16 needs to be added to the first view, the
   * partitions will be 0,1,2,3,16
   *
   * Param cluster_name        (IN) the name of the Kafka cluster 
   *                                (case insensitive)
   * Param group_name          (IN) the Kafka group that will be reading the 
   *                                topic (case sensitive)
   * Param topic_name          (IN) the topic name in the Kafka cluster whose 
   *                                contents will be retrieved (case sensitive)
   * Param views_created      (OUT) the number of views created.  A value of 
   *                                -1 is returned if there were no partitions
   *                                to add.
   *  
   */

  PROCEDURE ADD_PARTITIONS (
                       cluster_name         IN  VARCHAR2,
                       group_name           IN  VARCHAR2,
                       topic_name           IN  VARCHAR2,
                       views_created        OUT INTEGER 
  );

  /**
   * Deregister the Kafka cluster and optionally drop the topic views created 
   * on it.  
   * 
   * When cascade is set to true the cluster and all associated 
   * topic views are deleted.  It is set to false when an administrator
   * wants to drop the old cluster definition, and recreate it with different
   * properties (e.g. a modified bootstrap server list).  In the latter case,
   * applications must cease for the duration of recreating the cluster
   * definition. 
   *
   * Param cluster_name    (IN) the user supplied name for a Kafka cluster 
   *                            (case insensitive)
   * Param cascade         (IN) (OPTIONAL) if this is set to true, also drop the 
   *                            topic views on the Kafka cluster.  (Default
   *                            is TRUE).
   */
  PROCEDURE DROP_CLUSTER (
                          cluster_name  IN VARCHAR2,
                          cascade       IN BOOLEAN DEFAULT TRUE
  );

  /**
   * Drop views for a Kafka topic and remove the related location files.
   *
   * Param cluster_name    (IN) the user supplied name for a Kafka cluster
   *                            (case insensitive)
   * Param group_name      (IN) the Kafka consumer group ID (case sensitive)
   * Param topic_name      (IN) the Kafka topic name (case sensitive)
   */
  PROCEDURE DROP_VIEWS ( 
                        cluster_name IN VARCHAR2,
                        group_name   IN VARCHAR2,
                        topic_name   IN VARCHAR2
  );

  /**
   * Initializes the starting offset relative to the current Kafka high 
   * or low water mark of each Kafka partition belonging to the Kafka view.  
   * It would be typically called at the outset of a new application instance 
   * dedicated to processing the view or recovering after an application 
   * instance shutdown or failure.  
   * 
   * It serves to position the processing of Kafka records to a point 
   * that is relatively current, potentially skipping unprocessed older
   * records living in the Kafka partitions.  
   *
   * This call is optional.
   *
   * Param view_name        (IN) view_name 
   *                             (case insensitive)
   * Param record_count     (IN) the number of records before the high water 
   *                             mark or after the low water mark that 
   *                             designates the starting offset of each Kafka 
   *                             partition.
   * Param water_mark       (IN) the high or low watermark that indicates 
   *                             the desired relative positioning.
   *                             Restricted to WATER_MARK_HIGH or 
   *                             WATER_MARK_LOW constants defined in 
   *                             the Package Constants section above.
   */
   PROCEDURE INIT_OFFSET (
                         view_name           IN VARCHAR2,
                         record_count        IN INTEGER,
                         water_mark          IN VARCHAR2 
                                               DEFAULT WATER_MARK_HIGH
   );

  /**
   * Initializes the starting offset related to a timestamp 
   * for each Kafka partition belonging to the Kafka view.  
   * It would be typically called at the outset of a new application instance 
   * dedicated to processing the view or recovering after an application 
   * instance shutdown or failure.  
   * 
   * It serves to position the processing of Kafka records to a point 
   * that is relatively current, potentially skipping unprocessed older
   * records living in the Kafka partitions.  
   *
   * NOTE: The time between initializing of the offset and the first fetch may 
   * be delayed.  During this gap in time, it is possible that the record at 
   * the offset chosen has been deleted due to either the record exceeding the 
   * Kafka retention time or the record being explicitly removed. 
   *
   * This scenario requires an LRG to ensure the v1/v2/v3 implementations 
   * all function properly if a fetch occurs when the starting offset no 
   * longer exists.
   *
   * This call is optional.
   *
   * Param view_name        (IN) view_name 
   *                             (case insensitive)
   * Param milliseconds     (IN) the number of milliseconds since the epoch
   *
   */
  PROCEDURE INIT_OFFSET_TS (
                            view_name           IN VARCHAR2,
                            start_timestamp_ms  IN INTEGER);

  /**
   * Initializes the starting offset related to a timestamp 
   * for each Kafka partition belonging to the Kafka view.  
   * It would be typically called at the outset of a new application instance 
   * dedicated to processing the view or recovering after an application 
   * instance shutdown or failure.  
   * 
   * It serves to position the processing of Kafka records to a point 
   * that is relatively current, potentially skipping unprocessed older
   * records living in the Kafka partitions.  
   *
   * NOTE: The time between initializing of the offset and the first fetch may 
   * be delayed.  During this gap in time, it is possible that the record at 
   * the offset chosen has been deleted due to either the record exceeding the 
   * Kafka retention time or the record being explicitly removed. 
   *
   * This scenario requires an LRG to ensure the v1/v2/v3 implementations 
   * all function properly if a fetch occurs when the starting offset no 
   * longer exists.
   *
   * This call is optional.
   *
   * Param view_name        (IN) view_name 
   *                             (case insensitive)
   * Param start_timestamp  (IN) the timestamp of the offset you want to 
   *                             initialize to. The first record returned will
   *                             have a timestamp equal to the timestamp 
   *                             provided, or the nearest timestamp
   *                             greater than the timestamp provided.
   */
  PROCEDURE INIT_OFFSET_TS (
                            view_name           IN VARCHAR2,
                            start_timestamp     IN TIMESTAMP WITH TIME ZONE);

  /**
   * Initializes the starting offset related to a timestamp 
   * for each Kafka partition belonging to the Kafka view.  
   * It would be typically called at the outset of a new application instance 
   * dedicated to processing the view or recovering after an application 
   * instance shutdown or failure.  
   * 
   * It serves to position the processing of Kafka records to a point 
   * that is relatively current, potentially skipping unprocessed older
   * records living in the Kafka partitions.  
   *
   * NOTE: The time between initializing of the offset and the first fetch may 
   * be delayed.  During this gap in time, it is possible that the record at 
   * the offset chosen has been deleted due to either the record exceeding the 
   * Kafka retention time or the record being explicitly removed. 
   *
   * This scenario requires an LRG to ensure the v1/v2/v3 implementations 
   * all function properly if a fetch occurs when the starting offset no 
   * longer exists.
   *
   * This call is optional.
   *
   * Param view_name        (IN) view_name 
   *                             (case insensitive)
   * Param start_timestamp  (IN) the timestamp of the offset you want to 
   *                             initialize to. The first record returned will
   *                             have a timestamp equal to the timestamp 
   *                             provided, or the nearest timestamp
   *                             greater than the timestamp provided.
   * Param timezone         (IN) the time zone of the timestamp.  A null value
   *                             defaults to the session timezone
   */
  PROCEDURE INIT_OFFSET_TS (
                            view_name           IN VARCHAR2,
                            start_timestamp     IN TIMESTAMP,
                            timezone            IN VARCHAR2 DEFAULT NULL);

  /**
   * Loads a target table with content from a Kafka topic.  If the  
   * view is created, it will still exist after the completion of 
   * LOAD_TABLE. For subsequent calls for the same cluster, group, and topic, 
   * the existing view is reused and only the latest data since 
   * the previous LOAD_TABLE call is inserted into the target_table.
   *
   * NOTE: Failure to either insert the data into the target table or update
   * the offset will result in the rollback of the data.  The view created
   * is not part of the rollback and will exist if successfully created.
   *
   * Param cluster_name        (IN) the name of the Kafka cluster 
   *                                (case insensitive)
   * Param group_name          (IN) the Kafka group that will be reading the 
   *                                topic (case sensitive)
   * Param topic_name          (IN) the topic in the Kafka cluster whose
   *                                contents will be loaded (case sensitive)
   * Param topic_record_format (IN) the format of the Kafka record (e.g. 'CSV')
   *                                See constants defined in Package Constants 
   *                                in the top of the specification.
   * Param target_table        (IN) a target table in Oracle that will be loaded
   *                                It must reflect the shape of rows retrieved 
   *                                from Kafka.
   * Param records_loaded     (OUT) the number of Kafka records loaded
   */
  PROCEDURE LOAD_TABLE (
                        cluster_name        IN VARCHAR2,
                        group_name          IN VARCHAR2,
                        topic_name          IN VARCHAR2,
                        topic_record_format IN VARCHAR2,
                        target_table        IN VARCHAR2,
                        records_loaded     OUT INTEGER
  );


  /**
   * Usage Model for LOAD_GLOBAL_TEMP_TABLE versus LOAD_PRIVATE_TEMP_TABLE
   * -------------------------------------------------------------------------
   *
   * Oracle Kafka views are Kafka applications which are not transactional
   * within Oracle.  Each scan of a view will likely yield new results
   * since the view typically scans Kafka records from an offset to 
   * a topic's high water mark which is continually advancing.
   *
   * This becomes problematic if one wants consistency across several
   * SQL queries of the same data set retrieved from an Oracle Kafka 
   * view. It also becomes problematic if one is executing complicated 
   * joins with Oracle Kafka views without careful hinting in a SQL query 
   * that ensures the Oracle Kafka view is the outermost table in a join. 
   *
   * This operation solves these problems by creating a temporary table 
   * from a SELECT * FROM <view_name>, where view name is an Oracle Kafka 
   * view.  This materializes the data retrieved by a single query in a 
   * global temporary table.
   *
   * This procedure would typically be called immediately after calling 
   * NEXT_OFFSET, or SEEK_OFFSET.  After calling this procedure, application 
   * logic would query against the contents of a temporary table
   * rather then directly querying the Oracle Kafka view.
   *
   * Two types of temporary tables are useful: private temporary tables
   * and global temporary tables, which are created by calling 
   * LOAD_PRIVATE_TEMP_TABLE or LOAD_GLOBAL_TEMP_TABLE respectively.
   *
   * A key difference between global temp tables and private temp tables
   * is that global temp tables are more functional and are written to
   * disk, while private temp tables are strictly memory based.
   *
   * Specifically, global temporary tables support indexes and triggers. 
   * One would use a global temp table when one wants to fetch and 
   * aggregate Kafka data from several queries against an Oracle Kafka view 
   * before doing SQL analytics on full result set.
   * 
   * Private temporary tables would be used to simply put the results of
   * a single query against an Oracle Kafka view into a memory based table.
   * This is useful for doing joins against the result set, or when referencing
   * the data set multiple times either within a single analytic query, or in
   * several such queries.
   *
   */

  /**
   * PUBLIC METHOD
   *
   * Creates a global temporary table and loads it with contents from 
   * an Oracle Kafka view.
   *
   * If the global temporary table has already been created, the
   * procedure will simply load it with contents from a single query 
   * against the Oracle Kafka view.
   *
   * Once a temporary table is created it will endure in all sessions
   * for the Oracle schema.  At the outset of a new session it will
   * have no rows. 
   *
   * By default the global temporary table is created with ON COMMIT DELETE ROWS
   * semantics.  This means that either a COMMIT or ROLLBACK will delete the 
   * rows in the table.
   *
   * By setting preserve_rows to TRUE, the global temporary table will be
   * created with ON COMMIT PRESERVE ROWS.  This means that rows will be
   * be preserved on COMMIT and not deleted.  Afterwards one 
   * can call the procedure again to add more rows. One can also
   * truncate the table or delete rows.  Once one exits a session,
   * whatever data exists in the table is lost. 
   * 
   * By default the temporary table name will be "GTT_<view_name>".
   * The callers can provide their own temp_table_prefix as long as
   * it is compatible with the lexical requirement of Oracle table
   * names.
   *
   * See Usage Model section above for understanding when to use global 
   * temporary tables with Oracle Kafka views and when to use private 
   * temporary tables.
   *
   * Param view_name               (IN)  the name of the Oracle Kafka view
   * Param temp_table_name         (OUT) the name of a global temp table
   *                                     created and populated with a 
   *                                     SELECT * FROM <view_name>
   * Param preserve_rows           (IN)  (OPTIONAL) Defaults to FALSE.
   *                                     Ignored if temporary table already 
   *                                     exists.  If temporary table does not 
   *                                     exist and if FALSE, temporary table 
   *                                     is created such that it delete its rows 
   *                                     after the COMMIT.  If TRUE temporary 
   *                                     table is created to preserve rows
   *                                     after COMMIT.
   * Param temp_table_prefix       (IN)  (OPTIONAL) Defaults to 'GTT_'.
   *                                     Ignored if global temp table exists.
   */
  PROCEDURE LOAD_GLOBAL_TEMP_TABLE(view_name IN VARCHAR2, 
                                   temp_table_name OUT VARCHAR2,
                                   preserve_rows IN BOOLEAN DEFAULT FALSE,
                                   temp_table_prefix IN VARCHAR2 
                                      DEFAULT 'GTT_');

  /**
   * PUBLIC METHOD
   *
   * Creates and loads a private in-memory temporary table with contents
   * from an Oracle Kafka view.  If the temporary table exists from a
   * previous call to this procedure, it will simply load more data from
   * an Oracle Kafka view.
   *
   * By default, the duration of an Oracle private temporary table is the 
   * scope of a transaction.  It is created with ON COMMIT DROP DEFINITION.
   * This means that a COMMIT or ROLLBACK will delete the temporary table 
   * and its contents.
   *
   * If preserve_definition is set to TRUE, the temporary table will be
   * created with ON COMMIT PRESERVE DEFINITION.  This means that the 
   * table and data will be preserved on COMMIT.  On ROLLBACK the table
   * will be preserved, but any rows inserted in the transaction will be 
   * rolled back.
   *
   * See Usage Model section above for understanding when to use global 
   * temporary tables with Oracle Kafka views and when to use private 
   * temporary tables.
   *
   * Param view_name               (IN)  the name of the Oracle Kafka view
   * Param temp_table_name         (OUT) the name of a private temp table
   *                                     created and populated with a 
   *                                     SELECT * FROM <view_name>
   * Param preserve_definition     (IN)  (OPTIONAL) Defaults to FALSE.
   *                                     Ignored if private temp table exists.
   *                                     If FALSE, temp table will be dropped
   *                                     after COMMIT. If true the temp table 
   *                                     is preserved after commit.
   * Param temp_table_prefix       (IN)  (OPTIONAL) Defaults to 'ORA$PTT_'.
   *                                     Ignored if private temp table exists.
   *                                     A system defined prefix is required
   *                                     for private temporary table names.
   *                                     This prefix is set as the init.ora
   *                                     param: PRIVATE_TEMP_TABLE_PREFIX.
   *                                     If this init.ora param is set to 
   *                                     some other value, that value needs to be 
   *                                     passed in using this parameter. 
   *
   */
  PROCEDURE LOAD_PRIVATE_TEMP_TABLE(view_name IN VARCHAR2, 
                                    temp_table_name OUT VARCHAR2,
                                    preserve_definition IN BOOLEAN 
                                      DEFAULT FALSE,
                                    temp_table_prefix IN VARCHAR2 
                                      DEFAULT 'ORA$PTT_');

  /**
   * Advances the offsets belonging to a Kafka view, so the next SQL
   * query will process the next set of offsets.  This is called
   * prior to a SQL statement using the view, which will read data
   * from Kafka beginning at the specified offset.
   *
   * Param view_name    (IN) the name of Kafka view to be queried 
   *                         (case insensitive)
   */
  PROCEDURE NEXT_OFFSET (view_name IN VARCHAR2);
  
  /**
   * Seeks to a user defined offset and seek window size for a Kafka view.  
   * This must be called prior to a SQL SELECT statement using the Kafka
   * view.  This operation is restricted to Kafka views that map to
   * a single partition of a Kafka topic.
   *
   * Param view_name        (IN) the Kafka view that maps to a single 
   *                             cluster/topic/partition (case insensitive)
   * Param offset           (IN) a non-negative offset of the Kafka partition
   *                             to which to seek
   * Param window_size      (IN) the number of Kafka rows starting from 
   *                             the offset to be retrieved. 
   *
   *                             If 0 all data is read from the offset 
   *                             to the high water mark of the partition.
   *
   *                             If greater than zero then the window is
   *                             is used, qualified by the conditions 
   *                             stated below.
   *
   * If the window of rows expressed by offset and window_size
   * refers to messages that do not exist in the partition, the function
   * returns whatever messages do exist.  
   *
   * Specifically:
   *
   *  case 1: The offset is less than the current low water mark of 
   *          the Kafka partition.
   *          
   *          The function will start retrieving Kafka messages from the 
   *          low water mark up to but not including message at offset + 
   *          window_size
   *
   *  case 2: offset + window_size - 1 is greater than the current
   *          high water mark of the Kafka partition. 
   *
   *          The function retrieves Kafka messages up to and including the
   *          high water mark.
   *
   *  NOTE: SEEK_OFFSET is an alternative to NEXT_OFFSET.  SEEK_OFFSET main
   *        purpose is to position a Kafka view to start at a particular
   *        offset and sample a limited set of records.
   *  NOTE: UPDATE_OFFSET should be called after SEEK_OFFSET only if the
   *        desired behavior is to perform sequential access (NEXT_OFFSET) 
   *        based upon the last record returned from the random access 
   *        (SEEK_OFFSET) call.  Otherwise, the result of the SEEK_OFFSET 
   *        call has no effect on the NEXT_OFFSET call.
   *
   */
   PROCEDURE SEEK_OFFSET (
                         view_name        IN VARCHAR2, 
                         offset           IN INTEGER, 
                         window_size      IN INTEGER
   );

  /**
   * Seeks to a user defined window of time for a Kafka view.  
   * This must be called prior to a SQL SELECT statement using the Kafka
   * view.  This operation is restricted to Kafka views that map to
   * a single partition of a Kafka topic.
   *
   * Param view_name           (IN) the Kafka view that maps to a single 
   *                                cluster/topic/partition (case insensitive)
   * Param start_timestamp_ms  (IN) timestamp in milliseconds to seek the 
   *                                first record
   * Param end_timestamp_ms    (IN) timestamp in milliseconds to seek the 
   *                                last record
   *                             
   * If the window of rows expressed by the timestamps
   * refers to messages that do not exist in the partition, the function
   * returns whatever messages do exist.  
   *
   * Specifically:
   *
   *  case 0: If the timestamps are either both below the low water mark
   *          or above the high water mark, no rows will be returned
   *  case 1: If the start timestamp is below the low water mark, the first
   *          record will be the low water mark.
   *  case 2: If the end timestamp is above the high water mark, the last 
   *          record retrieved will be the high water mark - 1
   *
   *
   *  NOTE: SEEK_OFFSET_TS is an alternative to NEXT_OFFSET.  SEEK_OFFSET_TS 
   *        main purpose is to position a Kafka view to start at a particular
   *        timestamp and sample a limited set of records.
   *  NOTE: UPDATE_OFFSET should be called after SEEK_OFFSET_TS only if the
   *        desired behavior is to perform sequential access (NEXT_OFFSET) 
   *        based upon the last record returned from the random access 
   *        (SEEK_OFFSET_TS) call.  Otherwise, the result of the SEEK_OFFSET_TS 
   *        call has no effect on the NEXT_OFFSET call.
   *  NOTE: Records that are manually assigned timestamps are not gauranteed
   *        to be delivered in order.  Thus data may be interspersed and the 
   *        end time stamp offset may not contain earlier data that was 
   *        delivered late and thus has a high offset.  There is no way to 
   *        determine this scenario.
   *        
   */
  PROCEDURE SEEK_OFFSET_TS(
                view_name           IN VARCHAR2, 
                start_timestamp_ms  IN INTEGER,
                end_timestamp_ms    IN INTEGER);

  /**
   * Seeks to a user defined window of time for a Kafka view.  
   * This must be called prior to a SQL SELECT statement using the Kafka
   * view.  This operation is restricted to Kafka views that map to
   * a single partition of a Kafka topic.
   *
   * Param view_name        (IN) the Kafka view that maps to a single 
   *                             cluster/topic/partition (case insensitive)
   * Param start_timestamp  (IN) timestamp to seek the first record
   * Param end_timestamp    (IN) timestamp to seek the last record
   *                             
   * If the window of rows expressed by the timestamps
   * refers to messages that do not exist in the partition, the function
   * returns whatever messages do exist.  
   *
   * Specifically:
   *
   *  case 0: If the timestamps are either both below the low water mark
   *          or above the high water mark, no rows will be returned
   *  case 1: If the start timestamp is below the low water mark, the first
   *          record will be the low water mark.
   *  case 2: If the end timestamp is above the high water mark, the last 
   *          record retrieved will be the high water mark - 1
   *
   *
   *  NOTE: SEEK_OFFSET_TS is an alternative to NEXT_OFFSET.  SEEK_OFFSET_TS
   *        main purpose is to position a Kafka view to start at a particular
   *        timestamp and sample a limited set of records.
   *  NOTE: UPDATE_OFFSET should be called after SEEK_OFFSET_TS only if the
   *        desired behavior is to perform sequential access (NEXT_OFFSET) 
   *        based upon the last record returned from the random access 
   *        (SEEK_OFFSET_TS) call.  Otherwise, the result of the SEEK_OFFSET_TS 
   *        call has no effect on the NEXT_OFFSET call.
   *  NOTE: Records that are manually assigned timestamps are not gauranteed
   *        to be delivered in order.  Thus data may be interspersed and the 
   *        end time stamp offset may not contain earlier data that was 
   *        delivered late and thus has a high offset.  There is no way to 
   *        determine this scenario.
   *        
   */
  PROCEDURE SEEK_OFFSET_TS(
                view_name        IN VARCHAR2, 
                start_timestamp  IN TIMESTAMP WITH TIME ZONE, 
                end_timestamp    IN TIMESTAMP WITH TIME ZONE);
  /**
   * Seeks to a user defined window of time for a Kafka view.  
   * This must be called prior to a SQL SELECT statement using the Kafka
   * view.  This operation is restricted to Kafka views that map to
   * a single partition of a Kafka topic.
   *
   * Param view_name        (IN) the Kafka view that maps to a single 
   *                             cluster/topic/partition (case insensitive)
   * Param start_timestamp  (IN) timestamp to seek the first record
   * Param end_timestamp    (IN) timestamp to seek the last record
   * Param timezone         (IN) timezone of both of the timestamp arguments
   *                             If the value is null, the timezone is
   *                             the session timezone
   *                             
   * If the window of rows expressed by the timestamps
   * refers to messages that do not exist in the partition, the function
   * returns whatever messages do exist.  
   *
   * Specifically:
   *
   *  case 0: If the timestamps are either both below the low water mark
   *          or above the high water mark, no rows will be returned
   *  case 1: If the start timestamp is below the low water mark, the first
   *          record will be the low water mark.
   *  case 2: If the end timestamp is above the high water mark, the last 
   *          record retrieved will be the high water mark - 1
   *
   *
   *  NOTE: SEEK_OFFSET_TS is an alternative to NEXT_OFFSET.  SEEK_OFFSET_TS 
   *        main purpose is to position a Kafka view to start at a particular
   *        timestamp and sample a limited set of records.
   *  NOTE: UPDATE_OFFSET should be called after SEEK_OFFSET_TS only if the
   *        desired behavior is to perform sequential access (NEXT_OFFSET) 
   *        based upon the last record returned from the random access 
   *        (SEEK_OFFSET_TS) call.  Otherwise, the result of the SEEK_OFFSET_TS 
   *        call has no effect on the NEXT_OFFSET call.
   *  NOTE: Records that are manually assigned timestamps are not gauranteed
   *        to be delivered in order.  Thus data may be interspersed and the 
   *        end time stamp offset may not contain earlier data that was 
   *        delivered late and thus has a high offset.  There is no way to 
   *        determine this scenario.
   *        
   */
  PROCEDURE SEEK_OFFSET_TS(
                view_name        IN VARCHAR2, 
                start_timestamp  IN TIMESTAMP, 
                end_timestamp    IN TIMESTAMP,
                timezone         IN VARCHAR2 DEFAULT NULL);

  /**
   * Updates the last Kafka offsets read after using SQL to 
   * query the view. 
   *
   * Param view_name    (IN) the name of Kafka view used in a SQL
   *                         query to read one or more Kafka partitions
   *                         on behalf of an application
   */
  PROCEDURE UPDATE_OFFSET (view_name IN VARCHAR2);

  /**
   * Convert the input number of milliseconds since the epoch to a 
   * TIMESTAMP WITH TIME ZONE and return this value. If a timezone is 
   * provided as input, the return value will be relative to this timezone.
   * Otherwise the return value will be relative to the session's timezone  
   *
   * Param milliseconds (IN) number of milliseconds since the epoch
   * Param timezone     (IN) timezone to be used when returning the 
   *                         timestamp.  The default of NULL indicates
   *                         the session's timezone
   */
  FUNCTION CONVERT_MS_TO_TIMESTAMP_TZ(milliseconds INTEGER,
                                      timezone  VARCHAR2 DEFAULT NULL)
                                      RETURN TIMESTAMP WITH TIME ZONE;
  
  /**
   * Convert the input number of milliseconds since the epoch to a 
   * TIMESTAMP and return this value.
   *
   * Param milliseconds (IN) number of milliseconds since the epoch
   */
  FUNCTION CONVERT_MS_TO_TIMESTAMP(milliseconds INTEGER)
                                   RETURN TIMESTAMP;
  
  /**
   * Calculate and return the number of milliseconds since the epoch 
   * from the input TIMESTAMP WITH TIME ZONE.
   *
   * Param datetime_tz (IN) Timestamp to be converted to milliseconds
   */
  FUNCTION CONVERT_TIMESTAMP_TO_MS(datetime_tz TIMESTAMP WITH TIME ZONE)
                                   RETURN INTEGER;
  
  /**
   * Calculate and return the number of milliseconds since the epoch 
   * from the input TIMESTAMP.  The timestamp is considered to be in 
   * the session's timezone unless the timezone is provided.
   *
   * Param datetime (IN) Timestamp to be converted to milliseconds
   * Param timezone (IN) Timezone of the timestamp.  If not passed, 
   *                     the timezone defaults to the session's timezone
   */
  FUNCTION CONVERT_TIMESTAMP_TO_MS(datetime TIMESTAMP,
                                   timezone  VARCHAR2 DEFAULT NULL)
                                   RETURN INTEGER;

  -----------------------------------------------------------------------------
  --            END PACKAGE INTERFACE
  ---------------------------------------------------------------------------- 
  
END ORA_KAFKA;
/
SHOW ERRORS

