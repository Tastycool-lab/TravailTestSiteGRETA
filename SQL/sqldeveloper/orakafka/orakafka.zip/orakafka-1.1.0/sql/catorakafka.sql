Rem Copyright (c) 2018, 2019, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catorakafka.sql - Top level script to load Oracle orakafka
Rem
Rem    DESCRIPTION
Rem      This script installs the Oracle ORA_KAFKA and related packages 
Rem
Rem    NOTES
Rem      See Documentation.
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: hadoop/projects/dbmskafka/src/main/plsql/catorakafka.sql
Rem    SQL_SHIPPED_FILE: <ORAKAFKA_HOME>/sql/catorakafka.sql
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    END SQL_FILE_METADATA
Rem    
Rem    MODIFIED   (MM/DD/YY)
Rem    smavris     05/30/19 - Cleanup comments
Rem    myalavar    05/06/19 - dbms_kafka -> ora_kafka
Rem    rhanckel    11/02/18 - dbmskafkatab is wrapped
Rem    royan       07/16/18 - Add dbmskafka_location_dir
Rem    royan       06/25/18 - Move DBMS_KAFKA package installation to 
Rem                           dbmskafka_pkg_install.sql
Rem    rhanckel    05/27/05 - Created
Rem

prompt .. Creating ORA_KAFKA artifacts

Rem Create metadata tables for ORA_KAFKA

@@orakafkatab.plb

@@orakafka_pkg_install.sql


